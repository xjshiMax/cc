#!/bin/bash
while true; do ./client >/dev/null 2>&1; usleep 10000; done
