package math;
import java.util.*;
import java.lang.*;
public final class sm1 {
    public static final Map<Integer, String> value = create();

    private static Map<Integer, String> create() {
        Map<Integer, String> tmp_var16 = new HashMap<Integer, String>();

        tmp_var16.put(1, "first");

        return tmp_var16;
    }
}

