package math;
import java.util.*;
import java.lang.*;
public final class ss3 {
    public static final List<String> value = create();

    private static List<String> create() {
        List<String> tmp_var3 = new ArrayList<String>();

        tmp_var3.add("first");
        tmp_var3.add("second");

        return tmp_var3;
    }
}

