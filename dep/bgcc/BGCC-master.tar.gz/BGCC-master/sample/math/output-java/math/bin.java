package math;
import java.util.*;
import java.lang.*;
public final class bin {
    public static final java.lang.String value = "data";
}

