package math;
public final class GenderHolder {

    public GenderHolder() {
    }

    public GenderHolder(Gender value) {
        this.value = value;
    }

    public Gender value;
}

