package math;
import java.util.*;
import java.lang.*;
public final class ss1 {
    public static final List<Boolean> value = create();

    private static List<Boolean> create() {
        List<Boolean> tmp_var1 = new ArrayList<Boolean>();

        tmp_var1.add(true);
        tmp_var1.add(false);
        tmp_var1.add(false);

        return tmp_var1;
    }
}

