package math;
import java.util.*;
import java.lang.*;
public final class i8 {
    public static final byte value = 8;
}

