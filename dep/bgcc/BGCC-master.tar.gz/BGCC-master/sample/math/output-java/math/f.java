package math;
import java.util.*;
import java.lang.*;
public final class f {
    public static final float value = 3.3f;
}

