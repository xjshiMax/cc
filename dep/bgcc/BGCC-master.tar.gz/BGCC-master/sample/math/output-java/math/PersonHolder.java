package math;
public final class PersonHolder {

    public PersonHolder() {
    }

    public PersonHolder(Person value) {
        this.value = value;
    }

    public Person value;
}

