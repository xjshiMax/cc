package math;
import java.util.*;
import java.lang.*;
public final class i16 {
    public static final short value = 16;
}

