package common;
public final class AddressHolder {

    public AddressHolder() {
    }

    public AddressHolder(Address value) {
        this.value = value;
    }

    public Address value;
}

