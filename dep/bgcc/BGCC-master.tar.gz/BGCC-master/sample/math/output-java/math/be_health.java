package math;
import java.util.*;
import java.lang.*;
public final class be_health {
    public static final boolean value = true;
}

