package math;
import java.util.*;
import java.lang.*;
public final class i32 {
    public static final int value = 32;
}

