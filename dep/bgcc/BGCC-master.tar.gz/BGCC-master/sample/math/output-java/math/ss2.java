package math;
import java.util.*;
import java.lang.*;
public final class ss2 {
    public static final List<Integer> value = create();

    private static List<Integer> create() {
        List<Integer> tmp_var2 = new ArrayList<Integer>();

        tmp_var2.add(1);
        tmp_var2.add(2);
        tmp_var2.add(3);

        return tmp_var2;
    }
}

