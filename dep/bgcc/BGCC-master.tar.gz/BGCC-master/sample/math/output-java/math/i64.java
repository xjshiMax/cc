package math;
import java.util.*;
import java.lang.*;
public final class i64 {
    public static final long value = 64;
}

