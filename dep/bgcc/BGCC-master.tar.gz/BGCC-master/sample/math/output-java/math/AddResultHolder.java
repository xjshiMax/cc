package math;
public final class AddResultHolder {

    public AddResultHolder() {
    }

    public AddResultHolder(AddResult value) {
        this.value = value;
    }

    public AddResult value;
}

