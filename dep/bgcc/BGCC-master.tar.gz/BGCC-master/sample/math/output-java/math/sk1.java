package math;
import java.util.*;
import java.lang.*;
public final class sk1 {
    public static final Set<Boolean> value = create();

    private static Set<Boolean> create() {
        Set<Boolean> tmp_var9 = new HashSet<Boolean>();

        tmp_var9.add(true);
        tmp_var9.add(false);
        tmp_var9.add(false);

        return tmp_var9;
    }
}

