package math;
public final class ColorHolder {

    public ColorHolder() {
    }

    public ColorHolder(Color value) {
        this.value = value;
    }

    public Color value;
}

