package math;
public final class CitizenHolder {

    public CitizenHolder() {
    }

    public CitizenHolder(Citizen value) {
        this.value = value;
    }

    public Citizen value;
}

