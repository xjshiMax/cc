package math;
import java.util.*;
import java.lang.*;
public final class sk2 {
    public static final Set<Integer> value = create();

    private static Set<Integer> create() {
        Set<Integer> tmp_var10 = new HashSet<Integer>();

        tmp_var10.add(1);
        tmp_var10.add(2);
        tmp_var10.add(3);

        return tmp_var10;
    }
}

