package math;
import java.util.*;
import java.lang.*;
public final class str {
    public static final java.lang.String value = "hello";
}

