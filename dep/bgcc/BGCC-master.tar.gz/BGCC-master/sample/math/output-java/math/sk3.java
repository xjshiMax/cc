package math;
import java.util.*;
import java.lang.*;
public final class sk3 {
    public static final Set<String> value = create();

    private static Set<String> create() {
        Set<String> tmp_var11 = new HashSet<String>();

        tmp_var11.add("first");
        tmp_var11.add("second");

        return tmp_var11;
    }
}

