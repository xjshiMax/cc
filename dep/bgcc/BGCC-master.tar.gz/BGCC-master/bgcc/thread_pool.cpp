/***********************************************************************
  * Copyright (c) 2012, Baidu Inc. All rights reserved.
  * 
  * Licensed under the BSD License
  * you may not use this file except in compliance with the License.
  * You may obtain a copy of the License at
  * 
  *      license.txt
  *********************************************************************/

#include <iostream>
#include "thread_pool.h"
#include "thread_manager.h"

namespace bgcc {

    /**
     * @class ThreadPoolRunner
     * @brief �̳߳���������
     */
    class ThreadPool::ThreadPoolRunner : public Runnable {
    public:
        /**
         * @brief   �̳߳ع��캯��
         * @param   tp �̳߳�
         * @return  
         */
        ThreadPoolRunner(ThreadPool* tp);

        /**
         * @brief   ִ����
         * @param   
         * @return  
         */
        virtual int32_t operator()(const bool* isstopped, void* param);
    private:
        ThreadPool* _tp;
    };

    ThreadPool::ThreadPoolRunner::ThreadPoolRunner(ThreadPool* tp) : _tp(tp) {
    }

    int32_t ThreadPool::ThreadPoolRunner::operator()(const bool* isstopped, void* param) {
        while (!(*isstopped)) {
            RunnableSharedPointer pr;
            if(_tp->_tasks.get(pr, THREADPOOL_GET_TASK_TIMEOUT)==0&&pr.is_valid()){
                (*pr)(isstopped, param);
            }
        }
        return 1;
    }

    ThreadPool::ThreadPool() : _state(UNINITIALIZED) {
    }

    ThreadPool::~ThreadPool() {
        terminate();
    }

    int ThreadPool::init(int nThreads) {
        int ret = 0;
        if (UNINITIALIZED == _state) {
            _state = INITIALIZED;

            addWorker(nThreads);
        }

        return ret;
    }

    bool ThreadPool::addTask(RunnableSharedPointer pr) {
        return 0 == _tasks.put(pr);
    }

    bool ThreadPool::join() {
        return _threadGroup.join();
    }

    size_t ThreadPool::size() {
        return _threadGroup.size();
    }

    bool ThreadPool::terminate() {
        return _threadGroup.terminateAll();
    }

    int ThreadPool::addWorker(int nWorker) {
        int ret = 0;
        for (int i = 0; i < nWorker; ++i) {
            SharedPointer<Thread> workerThread = ThreadManager::createThread(
                    RunnableSharedPointer(new ThreadPoolRunner(this)));
            if (workerThread.is_valid()) {
                _threadGroup.addThread(workerThread);
                ++ret;
            }
        }
        return ret;
    }
}

