package math;
import java.util.*;
import java.lang.*;
public final class sk4 {
    public static final Set<Float> value = create();

    private static Set<Float> create() {
        Set<Float> tmp_var12 = new HashSet<Float>();

        tmp_var12.add(1.1f);
        tmp_var12.add(2.2f);
        tmp_var12.add(3.3f);

        return tmp_var12;
    }
}

