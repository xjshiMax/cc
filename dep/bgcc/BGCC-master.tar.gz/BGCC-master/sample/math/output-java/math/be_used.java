package math;
import java.util.*;
import java.lang.*;
public final class be_used {
    public static final boolean value = false;
}

